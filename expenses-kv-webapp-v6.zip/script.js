// Weekly Expenses (Cloudflare Pages + KV)
// No login. Sync key = Week Ending (Saturday) in YYYY-MM-DD.

const API = { data: '/api/data', weeks: '/api/weeks' };
const el = (id) => document.getElementById(id);

const dayCols = ['C','D','E','F','G','H','I']; // Sun..Sat
const dayIds  = ['SUN','MON','TUE','WED','THU','FRI','SAT'];

const rows = [
  {row:8,  label:'FROM',                   type:'text'},
  {row:9,  label:'TO',                     type:'text'},
  {row:10, label:'BUSINESS MILES DRIVEN',  type:'number'},

  {row:18, label:'Airfare', type:'currency'},
  {row:19, label:'Bus, Limo & Taxi', type:'currency'},
  {row:20, label:'Lodging Room & Tax', type:'currency'},
  {row:21, label:'Parking / Tolls', type:'currency'},
  {row:22, label:'Tips', type:'currency'},
  {row:23, label:'Laundry', type:'currency'},

  {row:25, label:'Auto Rental', type:'currency'},
  {row:26, label:'Auto Rental Fuel', type:'currency'},

  {row:34, label:'Internet - Email', type:'currency'},
  {row:36, label:'POSTAGE', type:'currency'},
  {row:38, label:'PERISHABLE TOOLS', type:'currency'},
  {row:39, label:'DUES & SUBSCRIPTIONS', type:'currency'},

  {row:42, label:'Breakfast', type:'currency'},
  {row:43, label:'Lunch', type:'currency'},
  {row:44, label:'Dinner', type:'currency'},
];

let currentWeekEnding = ''; // YYYY-MM-DD

function toISODate(d){
  const y=d.getFullYear();
  const m=String(d.getMonth()+1).padStart(2,'0');
  const da=String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${da}`;
}
function parseISODate(s){
  const [y,m,d]=s.split('-').map(Number);
  return new Date(y,m-1,d);
}
function computeWeekEndingFromSunday(sundayISO){
  const sun = parseISODate(sundayISO);
  const sat = new Date(sun);
  sat.setDate(sun.getDate()+6);
  return sat;
}
function computeSundayFromWeekEnding(weekEndingISO){
  const sat = parseISODate(weekEndingISO);
  const sun = new Date(sat);
  sun.setDate(sat.getDate()-6);
  return sun;
}
function fmtMD(d){
  return `${d.getMonth()+1}-${d.getDate()}`;
}
function weekLabel(weekEndingISO){
  const sat = parseISODate(weekEndingISO);
  const sun = computeSundayFromWeekEnding(weekEndingISO);
  return `Week ${fmtMD(sun)} through ${fmtMD(sat)}`;
}

function setStatus(msg=''){
  el('saveStatus').textContent = msg;
}

function buildTable(){
  const tbody = el('entryTable').querySelector('tbody');
  tbody.innerHTML = '';
  rows.forEach(r=>{
    const tr=document.createElement('tr');

    const tdLabel=document.createElement('td');
    tdLabel.className='stickyLabel';
    tdLabel.textContent=r.label;

    tr.appendChild(tdLabel);

    for (let i=0;i<7;i++){
      const td=document.createElement('td');
      const inp=document.createElement('input');
      inp.dataset.row=String(r.row);
      inp.dataset.col=dayCols[i];
      inp.dataset.type=r.type;

      if (r.type==='number'){
        inp.inputMode='numeric';
        inp.placeholder='0';
        inp.classList.add('number-right');
      } else if (r.type==='currency'){
        inp.inputMode='decimal';
        inp.placeholder='0.00';
        inp.classList.add('number-right');
      } else {
        inp.inputMode='text';
      }

      inp.addEventListener('input', computeTotals);
      if (r.type==='currency'){
        const wrap=document.createElement('div');
        wrap.className='currency-wrap';
        wrap.appendChild(inp);
        td.appendChild(wrap);
      } else {
        td.appendChild(inp);
      }
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  });
}

function allInputs(){
  return Array.from(el('entryTable').querySelectorAll('input'));
}

function clearInputs(){
  allInputs().forEach(i=>i.value='');
  el('businessPurpose').value='';
  computeTotals();
}

function computeTotals(){
  const totals=[0,0,0,0,0,0,0];
  allInputs().forEach(inp=>{
    if (inp.dataset.type!=='currency') return;
    const v=inp.value.trim();
    if (!v) return;
    const n=Number(v);
    if (!Number.isFinite(n)) return;
    const idx=dayCols.indexOf(inp.dataset.col);
    if (idx>=0) totals[idx]+=n;
  });
  let week=0;
  totals.forEach((t,idx)=>{
    week+=t;
    const out = t ? ('$' + t.toFixed(2)) : '';
    el(`tot${dayIds[idx]}`).value = out;
  });
  el('totWEEK').value = week ? ('$' + week.toFixed(2)) : '';
}

function serialize(){
  const entries={};
  allInputs().forEach(inp=>{
    const addr = `${inp.dataset.col}${inp.dataset.row}`;
    const raw = inp.value;
    if (raw==='') return;
    if (inp.dataset.type==='number' || inp.dataset.type==='currency'){
      const n=Number(raw);
      if (!Number.isFinite(n)) return;
      entries[addr]=n;
    } else {
      entries[addr]=raw;
    }
  });
  return {
    weekEnding: currentWeekEnding,
    businessPurpose: el('businessPurpose').value || '',
    entries
  };
}

function applyData(data){
  clearInputs();
  if (!data) return;
  el('businessPurpose').value = data.businessPurpose || '';
  const map = data.entries || {};
  allInputs().forEach(inp=>{
    const addr = `${inp.dataset.col}${inp.dataset.row}`;
    if (map[addr]==null) return;
    inp.value = String(map[addr]);
  });
  computeTotals();
}

async function apiFetchJson(url, opts={}){
  const headers = opts.headers ? {...opts.headers} : {};
  if (opts.body && !headers['Content-Type']) headers['Content-Type']='application/json';
  const res = await fetch(url, {...opts, headers});
  if (!res.ok){
    const t = await res.text().catch(()=> '');
    throw new Error(`${res.status} ${res.statusText}${t ? ' - '+t : ''}`);
  }
  return res.json();
}

async function refreshWeekDropdown(){
  try{
    const out = await apiFetchJson(API.weeks);
    const weeks = Array.isArray(out.weeks) ? out.weeks : [];
    const sel = el('weekSelect');
    const keep = sel.value;
    sel.innerHTML = '<option value="">(Select a week)</option>';
    weeks.forEach(we=>{
      const opt=document.createElement('option');
      opt.value=we;
      opt.textContent=weekLabel(we);
      sel.appendChild(opt);
    });
    if (keep && weeks.includes(keep)) sel.value=keep;
  } catch {
    // ignore
  }
}

async function loadWeek(){
  if (!currentWeekEnding) return;
  setStatus('Loading…');
  try{
    const out = await apiFetchJson(`${API.data}?weekEnding=${encodeURIComponent(currentWeekEnding)}`);
    applyData(out.data);
    setStatus(out.data ? 'Loaded.' : 'No saved data (new week).');
  } catch(e){
    setStatus('Load failed.');
  }
}

async function saveWeek(){
  if (!currentWeekEnding) return;
  setStatus('Saving…');
  try{
    await apiFetchJson(`${API.data}?weekEnding=${encodeURIComponent(currentWeekEnding)}`, {
      method:'PUT',
      body: JSON.stringify(serialize())
    });
    setStatus('Saved.');
    await refreshWeekDropdown();
    // ensure selected
    el('weekSelect').value = currentWeekEnding;
  } catch(e){
    setStatus('Save failed.');
  }
}

async function deleteWeek(){
  if (!currentWeekEnding) return;
  if (!confirm(`Delete saved data for ${weekLabel(currentWeekEnding)}?`)) return;
  setStatus('Deleting…');
  try{
    await apiFetchJson(`${API.data}?weekEnding=${encodeURIComponent(currentWeekEnding)}`, {method:'DELETE'});
    clearInputs();
    setStatus('Deleted.');
    await refreshWeekDropdown();
    el('weekSelect').value='';
  } catch{
    setStatus('Delete failed.');
  }
}

async function downloadExcel(){
  if (!currentWeekEnding) return;
  setStatus('Building Excel…');
  try{
    const templateRes = await fetch('Expenses Form.xlsx', {cache:'no-store'});
    const buf = await templateRes.arrayBuffer();
    const wb = XLSX.read(buf, {type:'array'});
    const ws = wb.Sheets['Page 1'] || wb.Sheets[wb.SheetNames[0]];

    // Week Ending (E4) and Business Purpose (G4)
    ws['E4'] = {t:'s', v: currentWeekEnding};
    const bp = el('businessPurpose').value || '';
    ws['G4'] = {t:'s', v: bp};

    // Date row (C7..I7)
    const sat = parseISODate(currentWeekEnding);
    const sun = computeSundayFromWeekEnding(currentWeekEnding);
    for (let i=0;i<7;i++){
      const d = new Date(sun);
      d.setDate(sun.getDate()+i);
      const addr = `${dayCols[i]}7`;
      ws[addr] = {t:'s', v: `${d.getMonth()+1}/${d.getDate()}/${d.getFullYear()}`};
    }

    // Entries
    const payload = serialize();
    for (const [addr,val] of Object.entries(payload.entries || {})){
      if (typeof val === 'number') ws[addr] = {t:'n', v: val};
      else ws[addr] = {t:'s', v: String(val)};
    }

    // Filename: Week m-d through m-d - Business Purpose.xlsx
    const mdSun = fmtMD(sun);
    const mdSat = fmtMD(sat);
    const safeBp = (bp || 'Expenses').replace(/[\\/:*?"<>|]+/g,'').trim();
    XLSX.writeFile(wb, `Week ${mdSun} through ${mdSat} - ${safeBp}.xlsx`);
    setStatus('Excel downloaded.');
  } catch {
    setStatus('Excel export failed.');
  }
}

// UI events
function setWeekFromSunday(sundayISO){
  const sat = computeWeekEndingFromSunday(sundayISO);
  currentWeekEnding = toISODate(sat);
  el('weekEnding').value = currentWeekEnding;
  el('weekSelect').value = currentWeekEnding; // may not exist yet; ok
}

el('sundayDate').addEventListener('change', async ()=>{
  const v = el('sundayDate').value;
  if (!v) return;
  setWeekFromSunday(v);
  await loadWeek(); // auto-load if it exists
});

el('weekSelect').addEventListener('change', async ()=>{
  const v = el('weekSelect').value;
  if (!v) return;
  currentWeekEnding = v;
  el('weekEnding').value = v;
  el('sundayDate').value = toISODate(computeSundayFromWeekEnding(v));
  await loadWeek();
});

el('btnSave').addEventListener('click', saveWeek);
el('btnDeleteWeek').addEventListener('click', deleteWeek);
el('btnClear').addEventListener('click', ()=>{ clearInputs(); setStatus('Cleared (not deleted).'); });
el('btnDownload').addEventListener('click', downloadExcel);

(function init(){
  buildTable();
  computeTotals();

  // Default to current week (Sunday of this week)
  const today = new Date();
  const sun = new Date(today);
  sun.setDate(today.getDate() - today.getDay());
  el('sundayDate').value = toISODate(sun);
  setWeekFromSunday(toISODate(sun));

  refreshWeekDropdown().then(async ()=>{
    // If this week exists in dropdown, keep it selected
    el('weekSelect').value = currentWeekEnding;
    await loadWeek();
  });

  // enable buttons once we have a week ending
  setButtonsEnabled(true);
})();

function setButtonsEnabled(on){
  el('btnSave').disabled = !on;
  el('btnClear').disabled = !on;
  el('btnDownload').disabled = !on;
  el('btnDeleteWeek').disabled = !on;
}
